#include <stdio.h>
#include "tests.h"

int main(void)
{
	test_run_all();
	
	return 0;
}