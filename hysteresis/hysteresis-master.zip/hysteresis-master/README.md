# Hysteresis

## Goal
Possible implementation of a 4 levels hysteresis

![alt_text](https://github.com/lille-boy/hysteresis/blob/master/diagram.png "Hysteresis diagram")

## Build
`make`

## Execute
`./hysteresis` to run the tests
